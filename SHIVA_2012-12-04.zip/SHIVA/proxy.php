<?
echo file_get_contents($url);
?>